import { useMemo, useState } from "react";
import { CheckCircle2, CircleDashed, ClipboardList, Plus, Sparkles, ArrowRight } from "lucide-react";
import Sidebar from "./components/Sidebar.jsx";
import Header from "./components/Header.jsx";
import StatCard from "./components/StatCard.jsx";
import FocusNotes from "./components/FocusNotes.jsx";
import SearchBar from "./components/SearchBar.jsx";
import FilterTabs from "./components/FilterTabs.jsx";
import TaskCard from "./components/TaskCard.jsx";
import TaskForm from "./components/TaskForm.jsx";
import CalendarView from "./components/CalendarView.jsx";
import { useLocalStorage } from "./hooks/useLocalStorage.js";
import { sampleTasks } from "./data/sampleTasks.js";

const STORAGE_KEY = "focusboard_tasks";

function OverviewPage({ tasks, stats, onGoToTasks, onEdit }) {
  const upcoming = [...tasks].filter((task) => task.status !== "Completed").sort((a, b) => (a.dueDate || "9999-12-31").localeCompare(b.dueDate || "9999-12-31")).slice(0, 4);
  return <div className="overview-page">
    <section className="welcome-row"><div><div className="date-kicker">YOUR WORKSPACE <span className="date-spark">✦</span></div><h1>Welcome to FocusBoard <span>✌️</span></h1><p>A clear view of your progress, priorities and next steps.</p></div><button className="primary-button welcome-add" onClick={onGoToTasks}>View all tasks <ArrowRight size={16} /></button></section>
    <section className="stats-grid" aria-label="Task overview statistics">
      <StatCard label="Total tasks" value={stats.total} detail="Tasks in your workspace" icon={ClipboardList} tone="purple" />
      <StatCard label="In progress" value={stats.inProgress} detail="Keep up the momentum" icon={CircleDashed} tone="orange" />
      <StatCard label="Completed" value={stats.completed} detail="Great work so far" icon={CheckCircle2} tone="green" />
      <StatCard label="Completion rate" value={`${stats.completion}%`} detail={`${stats.completed} of ${stats.total} tasks completed`} icon={Sparkles} tone="blue" progress={stats.completion} />
    </section>
    <FocusNotes />
    <section className="overview-bottom-grid">
      <div className="overview-panel"><div className="overview-panel-heading"><div><span className="section-kicker">UP NEXT</span><h2>Upcoming tasks</h2></div><button className="text-add-button" onClick={onGoToTasks}>See all <ArrowRight size={14} /></button></div>
        {upcoming.length ? upcoming.map((task) => <button className="upcoming-task" key={task.id} onClick={() => onEdit(task)}><span className={`upcoming-dot dot-${task.priority.toLowerCase()}`} /><span className="upcoming-copy"><strong>{task.title}</strong><small>{task.dueDate ? new Date(`${task.dueDate}T00:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "No due date"}</small></span><span className={`priority-pill priority-${task.priority.toLowerCase()}`}>{task.priority}</span></button>) : <p className="overview-empty">You're all caught up. Add a new task to get started.</p>}
      </div>
      <div className="overview-panel progress-panel"><div className="overview-panel-heading"><div><span className="section-kicker">YOUR MOMENTUM</span><h2>Task progress</h2></div><span className="progress-icon"><Sparkles size={17} /></span></div>
        <div className="progress-ring-wrap"><div className="progress-ring" style={{ "--progress": `${stats.completion * 3.6}deg` }}><div><strong>{stats.completion}%</strong><small>completed</small></div></div></div>
        <div className="progress-breakdown"><span><i className="breakdown-complete" />Completed <b>{stats.completed}</b></span><span><i className="breakdown-active" />In progress <b>{stats.inProgress}</b></span><span><i className="breakdown-todo" />To do <b>{stats.toDo}</b></span></div>
      </div>
    </section>
  </div>;
}

export default function App() {
  const [tasks, setTasks] = useLocalStorage(STORAGE_KEY, sampleTasks);
  const [search, setSearch] = useState("");
  const [activeStatus, setActiveStatus] = useState("All");
  const [priority, setPriority] = useState("All");
  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeNav, setActiveNav] = useState("Overview");
  const total = tasks.length;
  const inProgress = tasks.filter((task) => task.status === "In progress").length;
  const completed = tasks.filter((task) => task.status === "Completed").length;
  const toDo = tasks.filter((task) => task.status === "To do").length;
  const completion = total ? Math.round((completed / total) * 100) : 0;
  const stats = { total, inProgress, completed, toDo, completion };

  const visibleTasks = useMemo(() => tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(search.trim().toLowerCase());
    return matchesSearch && (activeStatus === "All" || task.status === activeStatus) && (priority === "All" || task.priority === priority);
  }), [tasks, search, activeStatus, priority]);

  const openCreate = () => { setEditingTask(null); setFormOpen(true); };
  const openEdit = (task) => { setEditingTask(task); setFormOpen(true); };
  const saveTask = (data) => {
    if (editingTask) setTasks((current) => current.map((task) => task.id === editingTask.id ? { ...data, id: editingTask.id } : task));
    else setTasks((current) => [{ ...data, id: `task-${Date.now()}` }, ...current]);
    setFormOpen(false); setEditingTask(null);
  };
  const deleteTask = (task) => {
    if (window.confirm(`Delete "${task.title}"? This task will be permanently removed.`)) setTasks((current) => current.filter((item) => item.id !== task.id));
  };
  const changeStatus = (id, status) => setTasks((current) => current.map((task) => task.id === id ? { ...task, status } : task));
  const resetFilters = () => { setSearch(""); setActiveStatus("All"); setPriority("All"); };

  return <div className="app-shell">
    <Sidebar activeNav={activeNav} setActiveNav={setActiveNav} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} taskCount={total} />
    <main className="main-panel">
      <Header activeNav={activeNav} onMenuClick={() => setMobileOpen(true)} onAddTask={openCreate} />
      <div className="page-content">
        {activeNav === "Overview" && <OverviewPage tasks={tasks} stats={stats} onGoToTasks={() => setActiveNav("My Tasks")} onEdit={openEdit} />}
        {activeNav === "My Tasks" && <>
          <section className="welcome-row"><div><div className="date-kicker">YOUR TASK SPACE <span className="date-spark">✦</span></div><h1>My tasks <span>✌️</span></h1><p>Organise your work and keep your day moving forward.</p></div><button className="primary-button welcome-add" onClick={openCreate}><Plus size={17} /> Add new task</button></section>
          <section className="stats-grid" aria-label="Task overview statistics">
            <StatCard label="Total tasks" value={total} detail="Tasks in your workspace" icon={ClipboardList} tone="purple" />
            <StatCard label="In progress" value={inProgress} detail="Keep up the momentum" icon={CircleDashed} tone="orange" />
            <StatCard label="Completed" value={completed} detail="Great work so far" icon={CheckCircle2} tone="green" />
            <StatCard label="Completion rate" value={`${completion}%`} detail={`${completed} of ${total} tasks completed`} icon={Sparkles} tone="blue" progress={completion} />
          </section>
          <section className="tasks-section">
            <div className="section-heading"><div><div className="section-kicker">YOUR WORKSPACE</div><h2>All tasks <span className="task-total">{total}</span></h2></div><button className="text-add-button" onClick={openCreate}><Plus size={16} /> Add task</button></div>
            <div className="task-toolbar"><SearchBar value={search} onChange={setSearch} /><FilterTabs activeStatus={activeStatus} setActiveStatus={setActiveStatus} priority={priority} setPriority={setPriority} onReset={resetFilters} /></div>
            <div className="task-list" aria-live="polite">{visibleTasks.length ? visibleTasks.map((task) => <TaskCard key={task.id} task={task} onEdit={openEdit} onDelete={deleteTask} onStatusChange={changeStatus} />) : <div className="empty-state"><div className="empty-icon">⌕</div><h3>No tasks found</h3><p>Try changing your search or filters to see more tasks.</p><button className="secondary-button" onClick={resetFilters}>Clear filters</button></div>}</div>
            <div className="list-footer"><span>Showing <strong>{visibleTasks.length}</strong> of <strong>{total}</strong> tasks</span><span>Changes save automatically</span></div>
          </section>
        </>}
        {activeNav === "Calendar" && <CalendarView tasks={tasks} onEdit={openEdit} />}
        {activeNav === "Settings" && <section className="settings-placeholder"><div className="section-kicker">PREFERENCES</div><h1>Settings</h1><p>FocusBoard stores your tasks in this browser using localStorage.</p><div className="settings-info"><strong>Task storage</strong><span>Local browser storage · Automatic saving enabled</span></div></section>}
        <footer className="page-footer">Made for meaningful progress <span>✦</span></footer>
      </div>
    </main>
    <TaskForm open={formOpen} task={editingTask} onClose={() => { setFormOpen(false); setEditingTask(null); }} onSave={saveTask} />
  </div>;
}
