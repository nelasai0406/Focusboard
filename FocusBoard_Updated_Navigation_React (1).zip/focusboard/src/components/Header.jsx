import { Bell, Menu, Search } from "lucide-react";
export default function Header({ activeNav = "My Tasks", onMenuClick, onAddTask }) {
  return <header className="topbar">
    <button className="icon-button mobile-menu-button" onClick={onMenuClick} aria-label="Open navigation"><Menu size={21} /></button>
    <div className="breadcrumb"><span>Workspace</span><b>/</b><strong>{activeNav}</strong></div>
    <div className="topbar-actions">
      {activeNav === "My Tasks" && <button className="top-search" aria-label="Search tasks" onClick={() => document.getElementById("task-search")?.focus()}><Search size={16} /><span>Search tasks</span><kbd>⌘ K</kbd></button>}
      <button className="icon-button notification-button" aria-label="Notifications"><Bell size={19} /><i /></button>
      <button className="header-add-button" onClick={onAddTask}><span>＋</span> Add task</button>
    </div>
  </header>;
}
