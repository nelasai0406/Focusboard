import { CalendarDays, MoreHorizontal, Pencil, Trash2 } from "lucide-react";

function formatDate(value) {
  if (!value) return "No due date";
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default function TaskCard({ task, onEdit, onDelete, onStatusChange }) {
  return (
    <article className="task-row">
      <div className={`task-check ${task.status === "Completed" ? "checked" : ""}`} aria-hidden="true">{task.status === "Completed" ? "✓" : ""}</div>
      <div className="task-main">
        <div className="task-title-line"><h3 className={task.status === "Completed" ? "completed-title" : ""}>{task.title}</h3><span className={`priority-pill priority-${task.priority.toLowerCase()}`}>{task.priority}</span></div>
        <p>{task.description || "No description added."}</p>
        <div className="task-meta"><span className="category-label">{task.category || "General"}</span><span className="due-date"><CalendarDays size={13} /> {formatDate(task.dueDate)}</span></div>
      </div>
      <div className="task-status-control">
        <label className="sr-only" htmlFor={`status-${task.id}`}>Status for {task.title}</label>
        <select id={`status-${task.id}`} className={`status-select status-${task.status.toLowerCase().replace(" ", "-")}`} value={task.status} onChange={(event) => onStatusChange(task.id, event.target.value)}>
          <option>To do</option><option>In progress</option><option>Completed</option>
        </select>
      </div>
      <div className="task-actions">
        <button className="icon-button task-action" onClick={() => onEdit(task)} aria-label={`Edit ${task.title}`}><Pencil size={15} /></button>
        <button className="icon-button task-action delete-action" onClick={() => onDelete(task)} aria-label={`Delete ${task.title}`}><Trash2 size={15} /></button>
      </div>
    </article>
  );
}
