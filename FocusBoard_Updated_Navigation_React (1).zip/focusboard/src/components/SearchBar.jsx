import { Search, X } from "lucide-react";

export default function SearchBar({ value, onChange }) {
  return (
    <label className="search-field">
      <Search size={17} />
      <span className="sr-only">Search tasks by title</span>
      <input id="task-search" type="search" placeholder="Search tasks..." value={value} onChange={(event) => onChange(event.target.value)} />
      {value && <button type="button" className="clear-search" onClick={() => onChange("")} aria-label="Clear search"><X size={15} /></button>}
    </label>
  );
}
