import { useEffect, useState } from "react";
import { X } from "lucide-react";

const emptyForm = { title: "", description: "", category: "Development", status: "To do", priority: "Medium", dueDate: "" };

export default function TaskForm({ open, task, onClose, onSave }) {
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setForm(task ? { ...emptyForm, ...task } : emptyForm);
      setError("");
    }
  }, [open, task]);

  if (!open) return null;

  const update = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  const submit = (event) => {
    event.preventDefault();
    const title = form.title.trim();
    if (!title) { setError("Please enter a task title."); return; }
    if (!form.status || !form.priority || !form.dueDate) { setError("Please complete the required fields."); return; }
    onSave({ ...form, title, description: form.description.trim() });
  };

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="task-modal" role="dialog" aria-modal="true" aria-labelledby="task-form-title">
        <div className="modal-heading"><div><span className="modal-kicker">{task ? "TASK DETAILS" : "NEW ITEM"}</span><h2 id="task-form-title">{task ? "Edit task" : "Create a task"}</h2><p>Capture the details and keep your work moving.</p></div><button className="icon-button" onClick={onClose} aria-label="Close form"><X size={20} /></button></div>
        <form onSubmit={submit}>
          <div className="form-field"><label htmlFor="task-title">Task title <span>*</span></label><input id="task-title" name="title" value={form.title} onChange={update} placeholder="e.g. Prepare project presentation" autoFocus /></div>
          <div className="form-field"><label htmlFor="task-description">Description</label><textarea id="task-description" name="description" value={form.description} onChange={update} placeholder="Add a few details about this task..." rows="3" /></div>
          <div className="form-grid">
            <div className="form-field"><label htmlFor="task-status">Status <span>*</span></label><select id="task-status" name="status" value={form.status} onChange={update}><option>To do</option><option>In progress</option><option>Completed</option></select></div>
            <div className="form-field"><label htmlFor="task-priority">Priority <span>*</span></label><select id="task-priority" name="priority" value={form.priority} onChange={update}><option>Low</option><option>Medium</option><option>High</option></select></div>
          </div>
          <div className="form-grid">
            <div className="form-field"><label htmlFor="task-category">Category</label><select id="task-category" name="category" value={form.category} onChange={update}><option>Design</option><option>Development</option><option>Testing</option><option>Research</option><option>Personal</option></select></div>
            <div className="form-field"><label htmlFor="task-due-date">Due date <span>*</span></label><input id="task-due-date" type="date" name="dueDate" value={form.dueDate} onChange={update} /></div>
          </div>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="modal-footer"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button type="submit" className="primary-button">{task ? "Save changes" : "Create task"}</button></div>
        </form>
      </section>
    </div>
  );
}
