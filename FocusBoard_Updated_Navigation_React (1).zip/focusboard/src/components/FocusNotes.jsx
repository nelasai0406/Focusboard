import { useState } from "react";
import { ArrowLeft, ArrowRight, Lightbulb } from "lucide-react";

const slides = [
  { eyebrow: "A LITTLE REMINDER", title: "Make room for deep work.", body: "Choose one meaningful task and give it your full attention. Progress comes from focus, not multitasking.", tag: "FOCUS TIP", color: "lavender" },
  { eyebrow: "YOUR DAILY RESET", title: "Plan it. Then start it.", body: "A clear plan turns a busy day into a series of manageable steps. Pick your next action and begin.", tag: "DAILY NOTE", color: "peach" },
  { eyebrow: "KEEP THE MOMENTUM", title: "Done is better than perfect.", body: "Celebrate the small wins. Every completed task is proof that you are moving forward.", tag: "MOTIVATION", color: "mint" },
];

export default function FocusNotes() {
  const [active, setActive] = useState(0);
  const move = (direction) => setActive((current) => (current + direction + slides.length) % slides.length);
  const slide = slides[active];

  return (
    <section className={`focus-notes ${slide.color}`} aria-label="Focus Notes carousel">
      <div className="focus-notes-top">
        <div className="focus-label"><span className="focus-spark"><Lightbulb size={15} /></span> FOCUS NOTES <span className="slide-count">· {active + 1} OF 3</span></div>
        <div className="carousel-controls">
          <button className="carousel-arrow" onClick={() => move(-1)} aria-label="Previous focus note"><ArrowLeft size={16} /></button>
          <button className="carousel-arrow" onClick={() => move(1)} aria-label="Next focus note"><ArrowRight size={16} /></button>
        </div>
      </div>
      <div className="focus-content" aria-live="polite">
        <div className="focus-copy">
          <span className="focus-eyebrow">{slide.eyebrow}</span>
          <h2>{slide.title}</h2>
          <p>{slide.body}</p>
          <span className="focus-tag">{slide.tag}</span>
        </div>
        <div className="focus-art" aria-hidden="true">
          <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
          <div className="art-sun">✦</div><div className="art-card"><span>today</span><b>One thing<br />at a time.</b><i>✓</i></div>
        </div>
      </div>
      <div className="carousel-dots" role="group" aria-label="Choose focus note">
        {slides.map((item, index) => <button key={item.title} className={`carousel-dot ${active === index ? "selected" : ""}`} onClick={() => setActive(index)} aria-label={`Show focus note ${index + 1}`} aria-pressed={active === index} />)}
      </div>
    </section>
  );
}
