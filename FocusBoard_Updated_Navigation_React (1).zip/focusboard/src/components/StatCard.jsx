export default function StatCard({ label, value, detail, icon: Icon, tone, progress }) {
  return (
    <article className="stat-card">
      <div className="stat-card-top">
        <span className="stat-label">{label}</span>
        <span className={`stat-icon ${tone}`}><Icon size={18} /></span>
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-foot">
        {progress !== undefined ? (
          <div className="mini-progress" aria-label={`${progress}% complete`}><span style={{ width: `${progress}%` }} /></div>
        ) : <span className="stat-dot" />}
        <span>{detail}</span>
      </div>
    </article>
  );
}
