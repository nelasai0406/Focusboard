import { SlidersHorizontal } from "lucide-react";

const statuses = ["All", "To do", "In progress", "Completed"];

export default function FilterTabs({ activeStatus, setActiveStatus, priority, setPriority, onReset }) {
  return (
    <div className="filters-row">
      <div className="filter-tabs" role="group" aria-label="Filter tasks by status">
        {statuses.map((status) => <button key={status} className={`filter-tab ${activeStatus === status ? "selected" : ""}`} onClick={() => setActiveStatus(status)} aria-pressed={activeStatus === status}>{status}</button>)}
      </div>
      <div className="filter-actions">
        <label className="priority-select-wrap"><SlidersHorizontal size={15} /><span className="sr-only">Filter by priority</span>
          <select value={priority} onChange={(event) => setPriority(event.target.value)} aria-label="Filter by priority">
            <option value="All">All priorities</option><option value="High">High priority</option><option value="Medium">Medium priority</option><option value="Low">Low priority</option>
          </select>
        </label>
        <button className="reset-filters" onClick={onReset}>Reset</button>
      </div>
    </div>
  );
}
