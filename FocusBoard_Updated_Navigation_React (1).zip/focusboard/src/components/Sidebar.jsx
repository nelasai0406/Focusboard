import { LayoutDashboard, CheckSquare, CalendarDays, Settings, X, Focus } from "lucide-react";
const navItems = [{ label: "Overview", icon: LayoutDashboard }, { label: "My Tasks", icon: CheckSquare }, { label: "Calendar", icon: CalendarDays }];
export default function Sidebar({ activeNav, setActiveNav, mobileOpen, onClose, taskCount = 0 }) {
  return <>
    {mobileOpen && <button className="sidebar-backdrop" aria-label="Close navigation" onClick={onClose} />}
    <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
      <div className="brand-row"><span className="brand-mark"><Focus size={21} strokeWidth={2.6} /></span><span className="brand-name">focus<span>board</span></span><button className="icon-button sidebar-close" onClick={onClose} aria-label="Close menu"><X size={19} /></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">
        {navItems.map(({ label, icon: Icon }) => <button key={label} className={`nav-item ${activeNav === label ? "active" : ""}`} onClick={() => { setActiveNav(label); onClose(); }} aria-current={activeNav === label ? "page" : undefined}>
          <Icon size={18} /><span>{label}</span>{label === "My Tasks" && <span className="nav-count">{String(taskCount).padStart(2, "0")}</span>}
        </button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-tip"><div className="tip-icon">✦</div><strong>Stay focused</strong><p>Small steps every day lead to big results.</p></div>
        <button className={`nav-item settings-item ${activeNav === "Settings" ? "active" : ""}`} onClick={() => { setActiveNav("Settings"); onClose(); }}><Settings size={18} /><span>Settings</span></button>
        <div className="profile-row"><div className="avatar">JD</div><div className="profile-copy"><strong>Jordan Davis</strong><span>Personal workspace</span></div><span className="profile-more">•••</span></div>
      </div>
    </aside>
  </>;
}
