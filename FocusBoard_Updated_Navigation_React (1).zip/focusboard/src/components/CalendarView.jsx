import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";

const weekdayLabels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const dateKey = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

export default function CalendarView({ tasks, onEdit }) {
  const [shownMonth, setShownMonth] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });
  const [selectedDate, setSelectedDate] = useState(() => dateKey(new Date()));
  const days = useMemo(() => {
    const first = new Date(shownMonth.getFullYear(), shownMonth.getMonth(), 1);
    const start = new Date(first);
    start.setDate(1 - first.getDay());
    return Array.from({ length: 42 }, (_, i) => {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      return date;
    });
  }, [shownMonth]);
  const tasksByDate = useMemo(() => tasks.reduce((groups, task) => {
    if (task.dueDate) groups[task.dueDate] = [...(groups[task.dueDate] || []), task];
    return groups;
  }, {}), [tasks]);
  const selectedTasks = tasksByDate[selectedDate] || [];
  const today = dateKey(new Date());
  const monthLabel = new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" }).format(shownMonth);
  const changeMonth = (step) => setShownMonth((current) => new Date(current.getFullYear(), current.getMonth() + step, 1));

  return (
    <section className="calendar-page">
      <div className="calendar-heading">
        <div><div className="section-kicker">PLAN YOUR TIME</div><h2>Calendar</h2><p>See your tasks by due date and plan what comes next.</p></div>
        <div className="calendar-month-controls">
          <button className="calendar-nav-button" onClick={() => changeMonth(-1)} aria-label="Previous month"><ChevronLeft size={18} /></button>
          <strong>{monthLabel}</strong>
          <button className="calendar-nav-button" onClick={() => changeMonth(1)} aria-label="Next month"><ChevronRight size={18} /></button>
          <button className="calendar-today-button" onClick={() => { const now = new Date(); setShownMonth(new Date(now.getFullYear(), now.getMonth(), 1)); setSelectedDate(today); }}>Today</button>
        </div>
      </div>
      <div className="calendar-layout">
        <div className="calendar-card">
          <div className="calendar-weekdays">{weekdayLabels.map((day) => <div key={day}>{day}</div>)}</div>
          <div className="calendar-grid">
            {days.map((date) => {
              const key = dateKey(date);
              const dayTasks = tasksByDate[key] || [];
              const inMonth = date.getMonth() === shownMonth.getMonth();
              return <button key={key} className={`calendar-day ${inMonth ? "" : "outside-month"} ${selectedDate === key ? "selected-day" : ""} ${today === key ? "today-day" : ""}`} onClick={() => setSelectedDate(key)} aria-pressed={selectedDate === key} aria-label={`${date.toDateString()}, ${dayTasks.length} tasks`}>
                <span className="calendar-day-number">{date.getDate()}</span>
                {dayTasks.slice(0, 2).map((task) => <span key={task.id} className={`calendar-event event-${task.priority.toLowerCase()}`}>{task.title}</span>)}
                {dayTasks.length > 2 && <span className="calendar-more">+{dayTasks.length - 2} more</span>}
                {dayTasks.length > 0 && <span className="calendar-mobile-dot" />}
              </button>;
            })}
          </div>
          <div className="calendar-legend"><span><i className="legend-high" /> High priority</span><span><i className="legend-medium" /> Medium priority</span><span><i className="legend-low" /> Low priority</span></div>
        </div>
        <aside className="calendar-agenda">
          <div className="agenda-heading"><div className="agenda-icon"><CalendarDays size={18} /></div><div><span>DAILY AGENDA</span><h3>{new Date(`${selectedDate}T00:00:00`).toLocaleDateString("en-US", { month: "long", day: "numeric" })}</h3></div></div>
          {selectedTasks.length ? <div className="agenda-task-list">{selectedTasks.map((task) => <div className="agenda-task" key={task.id}><div className={`agenda-priority-dot dot-${task.priority.toLowerCase()}`} /><div className="agenda-task-copy"><strong>{task.title}</strong><span>{task.status} · {task.priority} priority</span></div><button className="agenda-edit" onClick={() => onEdit(task)}>Edit</button></div>)}</div> : <div className="agenda-empty"><span>✦</span><strong>No tasks scheduled</strong><p>Select another date or add a due date to a task.</p></div>}
          <div className="agenda-summary"><strong>{selectedTasks.length}</strong><span>{selectedTasks.length === 1 ? "task" : "tasks"} scheduled</span></div>
        </aside>
      </div>
    </section>
  );
}
