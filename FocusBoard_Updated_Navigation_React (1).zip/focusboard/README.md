# FocusBoard — Task Management Dashboard

A responsive task management dashboard built with React, Vite, JavaScript and CSS. The project follows the requirements in the supplied MobileFirst assignment reference.

## Features

- Responsive dashboard layouts for desktop, tablet and mobile.
- Functional sidebar navigation between Overview, My Tasks and Calendar.
- Overview page with live statistics, upcoming tasks and a completion breakdown.
- Interactive monthly calendar with month navigation, Today shortcut, due-date markers and a selected-day agenda.
- Dynamic statistics: total tasks, in-progress tasks, completed tasks and completion percentage.
- Three-slide Focus Notes carousel with previous/next controls and direct slide indicators.
- Create and edit tasks using one reusable form.
- Delete tasks with a browser confirmation dialog.
- Task status updates from each task row.
- Case-insensitive, partial title search.
- Combined status and priority filters with reset.
- Six initial sample tasks across statuses, priorities and categories.
- Browser persistence with `localStorage`.
- Accessible labels, semantic landmarks, keyboard-operable controls and visible focus states.

## Technology stack

- React 18
- Vite
- JavaScript ES6+
- HTML5 and CSS3
- React Hooks (`useState`, `useEffect`, `useMemo`)
- Lucide React icons
- Browser `localStorage`

## Getting started

### Prerequisites

Install Node.js (which includes npm).

### Install and run

```bash
npm install
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

### Production build

```bash
npm run build
npm run preview
```

The production build is generated in the `dist` directory.

## Project structure

```text
focusboard/
├── public/
├── src/
│   ├── components/
│   │   ├── FilterTabs.jsx
│   │   ├── FocusNotes.jsx
│   │   ├── Header.jsx
│   │   ├── SearchBar.jsx
│   │   ├── Sidebar.jsx
│   │   ├── StatCard.jsx
│   │   ├── TaskCard.jsx
│   │   └── TaskForm.jsx
│   ├── data/
│   │   └── sampleTasks.js
│   ├── hooks/
│   │   └── useLocalStorage.js
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── index.html
├── package.json
├── vite.config.js
├── README.md
├── AI_USAGE.md
└── .gitignore
```

## State management

Task data is maintained in React state through the reusable `useLocalStorage` hook. The hook initialises state from the `focusboard_tasks` localStorage key when saved data exists; otherwise, it uses the six sample tasks.

- Create adds a task with a generated unique ID.
- Edit replaces the matching task while preserving its ID.
- Delete removes a task after confirmation.
- Status changes update only the selected task.
- Statistics are derived from the complete task array.
- Search and filters are derived from the complete task array and do not overwrite stored task data.
- The Focus Notes carousel maintains its active slide with local component state.

The hook writes the latest task array to localStorage whenever it changes. If browser storage is unavailable or contains invalid JSON, the app falls back to the sample data and logs the storage error.

## Responsive behaviour

- **Desktop (around 1440px):** fixed sidebar and multi-column statistics.
- **Tablet (around 768px):** narrower navigation and reflowed dashboard sections.
- **Mobile (around 390px):** slide-in navigation, stacked content and touch-friendly controls.

## Figma design note

The reference document says the supplied Figma file is the visual source of truth, but the actual Figma frames were not included with the text reference. This implementation provides a polished dashboard based on the written requirements. Update exact typography, spacing, colors, imagery and Focus Notes slide copy after comparing it with the actual Figma frames.

## Submission details

Fill in these links after publishing:

- GitHub repository: `PASTE_PUBLIC_GITHUB_URL_HERE`
- Deployed application: `PASTE_HTTPS_DEPLOYMENT_URL_HERE`

## Deployment

For Vercel or Netlify, use:

| Setting | Value |
|---|---|
| Framework | Vite |
| Install command | `npm install` |
| Build command | `npm run build` |
| Output directory | `dist` |

After deployment, open the HTTPS URL in a private/incognito browser window and test the CRUD features, filters, responsive layouts and localStorage persistence.

## Known limitations

- Data is stored locally in the current browser; there is no backend or cross-device synchronisation.
- Overview, My Tasks and Calendar are functional navigation pages. Settings currently displays a simple local-storage information panel.
- The dashboard copy and sample Focus Notes are illustrative and should be replaced with exact Figma content if supplied.
