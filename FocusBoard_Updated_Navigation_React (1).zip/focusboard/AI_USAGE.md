# AI Usage Disclosure

## Tools used

- ChatGPT was used to help prepare the project structure, implementation code and documentation.

## Representative prompts

1. Prepare a complete React/Vite task management dashboard based on the supplied FocusBoard assignment reference.
2. Implement task CRUD operations, status updates, search, combined filters and localStorage persistence.
3. Create a responsive dashboard with a three-slide manually controlled Focus Notes carousel.
4. Prepare README and AI usage documentation for the project.

## AI-assisted areas

- Initial component and folder structure.
- React component implementation and state flow.
- CSS layout and responsive styling.
- Sample task data.
- README and this disclosure document.

## Review and verification

The generated implementation should be reviewed and tested by the candidate before submission. In particular, compare the dashboard against the actual Figma frames, run the production build, test all interactions at 390px, 768px and 1440px, and verify localStorage behaviour. Any changes made during that review should be reflected in the final submission.
